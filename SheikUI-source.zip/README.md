# SheikUI

Interface iOS em SwiftUI, criada a partir das referências recebidas.

- Nome visual: **Sheik**
- Paleta: azul sobre azul-marinho
- Tela inicial: `IntroPhoto`
- Tela de terminal: `TerminalPhoto`
- Botões: apenas navegação visual, sem comandos, transferência ou acesso a dispositivo

Abra a pasta em um Mac com Xcode 16 ou mais recente. Crie um projeto iOS SwiftUI chamado `SheikUI` e substitua os arquivos pelo conteúdo desta pasta, ou adicione esta pasta a um projeto existente.
